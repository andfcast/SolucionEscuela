import { Component } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { Estudiante } from 'src/app/classes/estudiante';
import { BaseService } from 'src/app/services/base.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-listado-estudiantes',
  templateUrl: './listado-estudiantes.component.html',
  styleUrls: ['./listado-estudiantes.component.css']
})
export class ListadoEstudiantesComponent {
  controlador:string = 'Estudiante';
  lstEstudiantes:Estudiante[] = [];
  columnas:string[] = ['Id','Nombre', 'Acciones'];
  dataSource: any;
  constructor(private service: BaseService,     
    private route: ActivatedRoute,
    private router: Router){
  }
  ngOnInit(){
    this.ListarEstudiantes();
  }

  private ListarEstudiantes(){
    this.service.Listar(this.controlador).subscribe((res:any) =>{
      if(res.data != null){    
        this.lstEstudiantes = [];    
        res.data.forEach((element:Estudiante) => {          
          this.lstEstudiantes.push(element);
        });        
      }      
      this.dataSource = new MatTableDataSource<Estudiante>(this.lstEstudiantes);
    });
  }

  Crear(){
    this.router.navigateByUrl('CrearEstudiante');
  }
  Actualizar(id:number){
    this.router.navigateByUrl('ActualizarEstudiante/' + id.toString())
  }
  Borrar(id:number){
    Swal.fire({
      title: '¿Está seguro de borrar el registro?',
      text: 'Este proceso es irreversible',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.value) {
        this.service.Borrar(this.controlador,id).subscribe((data: any) => {
          if (data.exitoso) {
            Swal.fire({
              confirmButtonColor: '#a01533',
              showConfirmButton: false,
              timer:2000,
              text:'El registro ha sido borrado correctamente.',
              icon:'success'
            });
            setTimeout(() => {
              this.lstEstudiantes = this.lstEstudiantes.filter(x => x.id !== id);
              this.dataSource = new MatTableDataSource<Estudiante>(this.lstEstudiantes);              
            }, 1500);
          }
          else{
            Swal.fire({
              title: '¡Error!',
              text: data.mensaje,
              icon: 'error',
              timer:2000,
              confirmButtonColor: '#a01533',
              confirmButtonText: 'Aceptar'
            });
          }
        });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire({
          title:'Cancelado',
          text:'Borrado cancelado',
          icon:'info',
          showConfirmButton:false,
          timer:2000
        });
      }
    });
  }

}
