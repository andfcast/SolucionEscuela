import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Estudiante } from 'src/app/classes/estudiante';
import { BaseService } from 'src/app/services/base.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-editar-estudiante',
  templateUrl: './editar-estudiante.component.html',
  styleUrls: ['./editar-estudiante.component.css']
})
export class EditarEstudianteComponent {
  formEstudiante: FormGroup;
  controlador:string = 'Estudiante';
  idEstudiante!: number;
  estudiante:Estudiante = new Estudiante();

  constructor(
    private fb: FormBuilder,
    private service: BaseService,         
    private route: ActivatedRoute,
    private router: Router
  ){
    this.formEstudiante = this.fb.group({      
      nombre:['', Validators.required]                  
    }); 
    
  }

  ngOnInit(){
    this.idEstudiante = Number(this.router.url.split('/').pop());
    this.ObtenerInfo();    
  }

  private ObtenerInfo(){
    this.service.ObtenerInfo(this.controlador,this.idEstudiante).subscribe((res:any) =>{
      if(res.data != null){        
        this.estudiante = res.data;
        this.formEstudiante.setValue({
          nombre:this.estudiante.nombre          
        });
      }
    });
  }

  Guardar(){
    const valoresForm = this.formEstudiante.value;    
    this.estudiante.nombre = valoresForm.nombre;    
    this.service.Actualizar(this.controlador,this.estudiante).subscribe((data:any) =>{
      Swal.fire({
        text: 'Actualización exitosa',
        icon: 'success',
        timer:2000,
        confirmButtonColor: '#a01533',
        confirmButtonText: 'Aceptar'
      }); 
      setTimeout(() => {           
        this.router.navigateByUrl('/');    
      },1500);
    },
    error =>{
      Swal.fire({
        title: '¡Error!',
        text: 'Actualización no realizada',
        icon: 'error',
        timer:2000,
        confirmButtonColor: '#a01533',
        confirmButtonText: 'Aceptar'
      });
    });
  }
  Volver(){
    this.router.navigateByUrl('/Estudiantes');
  }

}
