import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Estudiante } from 'src/app/classes/estudiante';
import { BaseService } from 'src/app/services/base.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-crear-estudiante',
  templateUrl: './crear-estudiante.component.html',
  styleUrls: ['./crear-estudiante.component.css']
})
export class CrearEstudianteComponent {
  formEstudiante: FormGroup;
  estudiante:Estudiante = new Estudiante();
  controlador:string = 'Estudiante';

  constructor(
    private fb: FormBuilder,
    private service: BaseService,    
    private route: ActivatedRoute,
    private router: Router
  ){
    this.formEstudiante = this.fb.group({      
      nombre:['', Validators.required],      
    }); 
  }

  ngOnInit(){

  }

  Guardar(){
    const valoresForm = this.formEstudiante.value;    
    this.estudiante.nombre = valoresForm.nombre;
    this.service.Crear(this.controlador,this.estudiante).subscribe((data:any) =>{
      Swal.fire({
        text: 'Creación exitosa',
        icon: 'success',
        timer:2000,
        confirmButtonColor: '#a01533',
        confirmButtonText: 'Aceptar'
      }); 
      setTimeout(() => {           
        this.router.navigateByUrl('/');    
      },1500);
    },
    error =>{
      Swal.fire({
        title: '¡Error!',
        text: 'Creación no realizada',
        icon: 'error',
        timer:2000,
        confirmButtonColor: '#a01533',
        confirmButtonText: 'Aceptar'
      });
    });
  }
  Volver(){
    this.router.navigateByUrl('/Estudiantes');
  }
}
