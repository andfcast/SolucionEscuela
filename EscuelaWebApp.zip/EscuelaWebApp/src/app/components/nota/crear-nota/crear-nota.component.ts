import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Estudiante } from 'src/app/classes/estudiante';
import { Nota } from 'src/app/classes/nota';
import { Profesor } from 'src/app/classes/profesor';
import { BaseService } from 'src/app/services/base.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-crear-nota',
  templateUrl: './crear-nota.component.html',
  styleUrls: ['./crear-nota.component.css']
})
export class CrearNotaComponent {
  controlador:string = 'Nota';
  lstEstudiantes:Estudiante[] = [];
  lstProfesores:Profesor[] = [];
  formNota: FormGroup;
  nota:Nota = new Nota();

  constructor(private fb: FormBuilder,
    private service: BaseService,    
    private route: ActivatedRoute,
    private router: Router){
      this.formNota = this.fb.group({              
        asignatura:['', Validators.required],
        idEstudiante:['', Validators.required],
        idProfesor:['', Validators.required],
        valor:['', Validators.required, Validators.max(5), Validators.min(0)]        
      });
      this.ListarEstudiantes();
      this.ListarProfesores();
  }

  private ListarEstudiantes(){
    this.service.Listar('Estudiante').subscribe((res:any) =>{
      if(res.data != null){    
        this.lstEstudiantes = [];    
        res.data.forEach((element:Estudiante) => {          
          this.lstEstudiantes.push(element);
        });        
      }            
    });
  }

  private ListarProfesores(){
    this.service.Listar('Profesor').subscribe((res:any) =>{
      if(res.data != null){    
        this.lstProfesores = [];    
        res.data.forEach((element:Profesor) => {          
          this.lstProfesores.push(element);
        });        
      }            
    });
  }

  Guardar(){
    const valoresForm = this.formNota.value;      
    this.nota.asignatura = valoresForm.asignatura;
    this.nota.idEstudiante = valoresForm.idEstudiante;
    this.nota.idProfesor = valoresForm.idProfesor;
    this.nota.valor = valoresForm.valor;        
    this.service.Crear(this.controlador,this.nota).subscribe((data:any) =>{
      Swal.fire({
        text: 'Creación exitosa',
        icon: 'success',
        timer:2000,
        confirmButtonColor: '#a01533',
        confirmButtonText: 'Aceptar'
      }); 
      setTimeout(() => {           
        this.router.navigateByUrl('Notas');    
      },1500);
    },
    error =>{
      Swal.fire({
        title: '¡Error!',
        text: 'Creación no realizada',
        icon: 'error',
        timer:2000,
        confirmButtonColor: '#a01533',
        confirmButtonText: 'Aceptar'
      });
    });
  }
  Volver(){
    this.router.navigateByUrl('Notas');
  }

}
