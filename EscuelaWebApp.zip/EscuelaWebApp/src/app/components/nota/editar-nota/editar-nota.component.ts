import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Estudiante } from 'src/app/classes/estudiante';
import { Nota } from 'src/app/classes/nota';
import { Profesor } from 'src/app/classes/profesor';
import { BaseService } from 'src/app/services/base.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-editar-nota',
  templateUrl: './editar-nota.component.html',
  styleUrls: ['./editar-nota.component.css']
})
export class EditarNotaComponent {
  controlador:string = 'Nota';
  lstEstudiantes:Estudiante[] = [];
  lstProfesores:Profesor[] = [];
  formNota: FormGroup;
  idNota!:number;
  nota:Nota = new Nota();

  constructor(private fb: FormBuilder,
    private service: BaseService,    
    private route: ActivatedRoute,
    private router: Router){
      this.formNota = this.fb.group({              
        asignatura:['', Validators.required],
        idEstudiante:['', Validators.required],
        idProfesor:['', Validators.required],
        valor:['', Validators.required]        
      });
      this.ListarEstudiantes();
      this.ListarProfesores();
  }

  ngOnInit(){
    this.idNota = Number(this.router.url.split('/').pop());
    this.ObtenerInfo()    
  }

  private ListarEstudiantes(){
    this.service.Listar('Estudiante').subscribe((res:any) =>{
      if(res.data != null){    
        this.lstEstudiantes = [];    
        res.data.forEach((element:Estudiante) => {          
          this.lstEstudiantes.push(element);
        });        
      }            
    });
  }

  private ListarProfesores(){
    this.service.Listar('Profesor').subscribe((res:any) =>{
      if(res.data != null){    
        this.lstProfesores = [];    
        res.data.forEach((element:Profesor) => {          
          this.lstProfesores.push(element);
        });        
      }            
    });
  }

  ObtenerInfo(){
    this.service.ObtenerInfo(this.controlador,this.idNota).subscribe((res:any) =>{
      if(res.data != null){        
        this.nota = res.data;
        this.formNota.setValue({          
          asignatura:this.nota.asignatura,
          idEstudiante:this.nota.idEstudiante,
          idProfesor:this.nota.idProfesor,          
          valor:this.nota.valor  
        });
      }
    });
  }

  Guardar(){
    const valoresForm = this.formNota.value;        
    this.nota.asignatura = valoresForm.asignatura;
    this.nota.idEstudiante = valoresForm.idEstudiante;
    this.nota.idProfesor = valoresForm.idProfesor;
    this.nota.valor = valoresForm.valor;        
    this.service.Actualizar(this.controlador,this.nota).subscribe((data:any) =>{
      Swal.fire({
        text: 'Actualización exitosa',
        icon: 'success',
        timer:2000,
        confirmButtonColor: '#a01533',
        confirmButtonText: 'Aceptar'
      }); 
      setTimeout(() => {           
        this.router.navigateByUrl('Notas');    
      },1500);
    },
    error =>{
      Swal.fire({
        title: '¡Error!',
        text: 'Actualización no realizada',
        icon: 'error',
        timer:2000,
        confirmButtonColor: '#a01533',
        confirmButtonText: 'Aceptar'
      });
    });
  }
  Volver(){
    this.router.navigateByUrl('Notas');
  }
}
