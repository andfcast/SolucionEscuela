import { Component } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { Estudiante } from 'src/app/classes/estudiante';
import { Nota } from 'src/app/classes/nota';
import { Profesor } from 'src/app/classes/profesor';
import { BaseService } from 'src/app/services/base.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-listado-notas',
  templateUrl: './listado-notas.component.html',
  styleUrls: ['./listado-notas.component.css']
})
export class ListadoNotasComponent {
  controlador:string = 'Nota';
  lstEstudiantes:Estudiante[] = [];
  lstProfesores:Profesor[] = [];
  lstNotas:Nota[] = [];
  columnas:string[] = ['Id','Asignatura','Estudiante','Profesor','Valor', 'Acciones'];
  dataSource: any;
  constructor(private service: BaseService,     
    private route: ActivatedRoute,
    private router: Router){
      this.ListarEstudiantes();
      this.ListarProfesores();
  }
  ngOnInit(){    
    this.ListarNotas();    
  }

  private ListarEstudiantes(){
    this.service.Listar('Estudiante').subscribe((res:any) =>{
      if(res.data != null){    
        this.lstEstudiantes = [];    
        res.data.forEach((element:Estudiante) => {          
          this.lstEstudiantes.push(element);
        });        
      }            
    });
  }

  private ListarProfesores(){
    this.service.Listar('Profesor').subscribe((res:any) =>{
      if(res.data != null){    
        this.lstProfesores = [];    
        res.data.forEach((element:Profesor) => {          
          this.lstProfesores.push(element);
        });        
      }            
    });
  }

  private ListarNotas(){
    this.service.Listar(this.controlador).subscribe((res:any) =>{
      if(res.data != null){    
        this.lstNotas = [];    
        res.data.forEach((element:Nota) => {          
          this.lstNotas.push(element);
        });        
      }      
      this.dataSource = new MatTableDataSource<Nota>(this.lstNotas);
    });
  }

  BuscarNombreEstudiante(id:number):string {    
    return this.lstEstudiantes.find(x => x.id == id)!.nombre;
  }

  BuscarNombreProfesor(id:number):string {
    return this.lstProfesores.find(x => x.id == id)!.nombre;
  }

  Crear(){
    this.router.navigateByUrl('CrearNota');
  }
  Actualizar(id:number){
    this.router.navigateByUrl('ActualizarNota/' + id.toString())
  }
  Borrar(id:number){
    Swal.fire({
      title: '¿Está seguro de borrar el registro?',
      text: 'Este proceso es irreversible',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.value) {
        this.service.Borrar(this.controlador,id).subscribe((data: any) => {
          if (data.exitoso) {
            Swal.fire({
              confirmButtonColor: '#a01533',
              showConfirmButton: false,
              timer:2000,
              text:'El registro ha sido borrado correctamente.',
              icon:'success'
            });
            setTimeout(() => {
              this.lstNotas = this.lstNotas.filter(x => x.id !== id);
              this.dataSource = new MatTableDataSource<Nota>(this.lstNotas);              
            }, 1500);
          }
          else{
            Swal.fire({
              title: '¡Error!',
              text: data.mensaje,
              icon: 'error',
              timer:2000,
              confirmButtonColor: '#a01533',
              confirmButtonText: 'Aceptar'
            });
          }
        });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire({
          title:'Cancelado',
          text:'Borrado cancelado',
          icon:'info',
          showConfirmButton:false,
          timer:2000
        });
      }
    });
  }
}
