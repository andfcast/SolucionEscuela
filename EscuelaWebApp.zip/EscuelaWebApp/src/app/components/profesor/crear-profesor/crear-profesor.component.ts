import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Profesor } from 'src/app/classes/profesor';
import { BaseService } from 'src/app/services/base.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-crear-profesor',
  templateUrl: './crear-profesor.component.html',
  styleUrls: ['./crear-profesor.component.css']
})
export class CrearProfesorComponent {
  formProfesor: FormGroup;
  profesor:Profesor = new Profesor();
  controlador:string = 'Profesor';

  constructor(
    private fb: FormBuilder,
    private service: BaseService,    
    private route: ActivatedRoute,
    private router: Router
  ){
    this.formProfesor = this.fb.group({      
      nombre:['', Validators.required],      
    }); 
  }

  ngOnInit(){

  }

  Guardar(){
    const valoresForm = this.formProfesor.value;    
    this.profesor.nombre = valoresForm.nombre;
    this.service.Crear(this.controlador,this.profesor).subscribe((data:any) =>{
      Swal.fire({
        text: 'Creación exitosa',
        icon: 'success',
        timer:2000,
        confirmButtonColor: '#a01533',
        confirmButtonText: 'Aceptar'
      }); 
      setTimeout(() => {           
        this.router.navigateByUrl('Profesores');    
      },1500);
    },
    error =>{
      Swal.fire({
        title: '¡Error!',
        text: 'Creación no realizada',
        icon: 'error',
        timer:2000,
        confirmButtonColor: '#a01533',
        confirmButtonText: 'Aceptar'
      });
    });
  }
  Volver(){
    this.router.navigateByUrl('Profesores');
  }
}
