import { Component } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { Profesor } from 'src/app/classes/profesor';
import { BaseService } from 'src/app/services/base.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-listado-profesores',
  templateUrl: './listado-profesores.component.html',
  styleUrls: ['./listado-profesores.component.css']
})
export class ListadoProfesoresComponent {
  controlador:string = 'Profesor';
  lstProfesores:Profesor[] = [];
  columnas:string[] = ['Id','Nombre', 'Acciones'];
  dataSource: any;
  constructor(private service: BaseService,     
    private route: ActivatedRoute,
    private router: Router){
  }
  ngOnInit(){
    this.ListarProfesores();
  }

  private ListarProfesores(){
    this.service.Listar(this.controlador).subscribe((res:any) =>{
      if(res.data != null){    
        this.lstProfesores = [];    
        res.data.forEach((element:Profesor) => {          
          this.lstProfesores.push(element);
        });        
      }      
      this.dataSource = new MatTableDataSource<Profesor>(this.lstProfesores);
    });
  }

  Crear(){
    this.router.navigateByUrl('CrearProfesor');
  }
  Actualizar(id:number){
    this.router.navigateByUrl('ActualizarProfesor/' + id.toString())
  }
  Borrar(id:number){
    Swal.fire({
      title: '¿Está seguro de borrar el registro?',
      text: 'Este proceso es irreversible',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.value) {
        this.service.Borrar(this.controlador,id).subscribe((data: any) => {
          if (data.exitoso) {
            Swal.fire({
              confirmButtonColor: '#a01533',
              showConfirmButton: false,
              timer:2000,
              text:'El registro ha sido borrado correctamente.',
              icon:'success'
            });
            setTimeout(() => {
              this.lstProfesores = this.lstProfesores.filter(x => x.id !== id);
              this.dataSource = new MatTableDataSource<Profesor>(this.lstProfesores);              
            }, 1500);
          }
        });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire({
          title:'Cancelado',
          text:'Borrado cancelado',
          icon:'info',
          showConfirmButton:false,
          timer:2000
        });
      }
    });
  }
}
