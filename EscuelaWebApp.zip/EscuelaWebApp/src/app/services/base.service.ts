import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BaseService {
  
  constructor(private _httpClient: HttpClient) { }

  Listar(controlador:string):Observable<any>{
    return this._httpClient.get(environment.SERVICE_URL + controlador + '/Listar');
  }

  ObtenerInfo(controlador:string,id:number):Observable<any>{
    return this._httpClient.get(environment.SERVICE_URL + controlador +'/Obtener/' + id.toString());
  }

  Crear(controlador:string,dto:any):Observable<any>{
    return this._httpClient.post(environment.SERVICE_URL + controlador + '/Crear',dto);
  }

  Actualizar(controlador:string,dto:any):Observable<any>{
    return this._httpClient.put(environment.SERVICE_URL + controlador + '/Actualizar/' + dto.id.toString(),dto);
  }

  Borrar(controlador:string,id: number):Observable<any>{
    return this._httpClient.delete(environment.SERVICE_URL + controlador + '/Borrar/' + id.toString());
  }

}
