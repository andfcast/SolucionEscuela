import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ListadoEstudiantesComponent } from './components/estudiante/listado-estudiantes/listado-estudiantes.component';
import { CrearEstudianteComponent } from './components/estudiante/crear-estudiante/crear-estudiante.component';
import { EditarEstudianteComponent } from './components/estudiante/editar-estudiante/editar-estudiante.component';
import { ListadoProfesoresComponent } from './components/profesor/listado-profesores/listado-profesores.component';
import { EditarProfesorComponent } from './components/profesor/editar-profesor/editar-profesor.component';
import { CrearProfesorComponent } from './components/profesor/crear-profesor/crear-profesor.component';
import { CrearNotaComponent } from './components/nota/crear-nota/crear-nota.component';
import { EditarNotaComponent } from './components/nota/editar-nota/editar-nota.component';
import { ListadoNotasComponent } from './components/nota/listado-notas/listado-notas.component';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HttpClientJsonpModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { MAT_DATE_LOCALE } from '@angular/material/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from 'src/shared/shared.module';

@NgModule({
  declarations: [
    AppComponent,
    ListadoEstudiantesComponent,
    CrearEstudianteComponent,
    EditarEstudianteComponent,
    ListadoProfesoresComponent,
    EditarProfesorComponent,
    CrearProfesorComponent,
    CrearNotaComponent,
    EditarNotaComponent,
    ListadoNotasComponent
  ],
  imports: [
    BrowserModule,
    RouterModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    HttpClientModule,
    HttpClientJsonpModule,
    CommonModule,
    SharedModule
  ],
  providers: [{provide: MAT_DATE_LOCALE, useValue: 'es-CO'}],
  bootstrap: [AppComponent]
})
export class AppModule { }
