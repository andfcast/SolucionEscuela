export class Estudiante{
    id!: number;
    nombre!: string;
}