export class Profesor{
    id!: number;
    nombre!: string;
}