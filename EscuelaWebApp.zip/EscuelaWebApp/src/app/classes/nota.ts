export class Nota{
    id!:number;
    asignatura!:string;
    idProfesor!:number;
    idEstudiante!:number;
    valor!:number;
}