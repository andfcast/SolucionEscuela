import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListadoEstudiantesComponent } from './components/estudiante/listado-estudiantes/listado-estudiantes.component';
import { CrearEstudianteComponent } from './components/estudiante/crear-estudiante/crear-estudiante.component';
import { EditarEstudianteComponent } from './components/estudiante/editar-estudiante/editar-estudiante.component';
import { CrearProfesorComponent } from './components/profesor/crear-profesor/crear-profesor.component';
import { ListadoProfesoresComponent } from './components/profesor/listado-profesores/listado-profesores.component';
import { EditarProfesorComponent } from './components/profesor/editar-profesor/editar-profesor.component';
import { ListadoNotasComponent } from './components/nota/listado-notas/listado-notas.component';
import { CrearNotaComponent } from './components/nota/crear-nota/crear-nota.component';
import { EditarNotaComponent } from './components/nota/editar-nota/editar-nota.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'Estudiantes',
    pathMatch: 'full',
  },
  {
    path: 'Estudiantes',
    component: ListadoEstudiantesComponent,
    data: {
      title: 'Estudiantes'
    },    
  },
    {
      path: 'CrearEstudiante',
      component: CrearEstudianteComponent,
      data: {
        title: 'Registrar Nuevo Estudiante'
      }
    },
    {
      path: 'ActualizarEstudiante/:id',
      component: EditarEstudianteComponent,
      data: {
        title: 'Actualizar Estudiante'
      }
    },
    {
      path: 'Profesores',
      component: ListadoProfesoresComponent,
      data: {
        title: 'Profesores'
      },    
    },
      {
        path: 'CrearProfesor',
        component: CrearProfesorComponent,
        data: {
          title: 'Registrar Nuevo Profesor'
        }
      },
      {
        path: 'ActualizarProfesor/:id',
        component: EditarProfesorComponent,
        data: {
          title: 'Actualizar Profesor'
        }
      },
      {
        path: 'Notas',
        component: ListadoNotasComponent,
        data: {
          title: 'Notas'
        },    
      },
        {
          path: 'CrearNota',
          component: CrearNotaComponent,
          data: {
            title: 'Registrar Nuevo Estudiante'
          }
        },
        {
          path: 'ActualizarNota/:id',
          component: EditarNotaComponent,
          data: {
            title: 'Actualizar Nota'
          }
        },
    
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
